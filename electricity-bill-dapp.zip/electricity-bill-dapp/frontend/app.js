// ABI from the compiled contract JSON file
const abi = [ {
    "inputs": [
        { "internalType": "uint256", "name": "_ratePerUnit", "type": "uint256" }
    ],
    "stateMutability": "nonpayable",
    "type": "constructor"
},
{
    "inputs": [
        { "internalType": "uint256", "name": "previousReading", "type": "uint256" },
        { "internalType": "uint256", "name": "currentReading", "type": "uint256" }
    ],
    "name": "generateBill",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
},
{
    "inputs": [],
    "name": "getBill",
    "outputs": [
        {
            "components": [
                { "internalType": "uint256", "name": "previousReading", "type": "uint256" },
                { "internalType": "uint256", "name": "currentReading", "type": "uint256" },
                { "internalType": "uint256", "name": "unitsUsed", "type": "uint256" },
                { "internalType": "uint256", "name": "billAmount", "type": "uint256" }
            ],
            "internalType": "struct ElectricityBill.Bill",
            "name": "",
            "type": "tuple"
        }
    ],
    "stateMutability": "view",
    "type": "function"
}
    // Replace with the ABI content from the JSON file
  ];
  
  // Replace this with your deployed contract address
  const contractAddress = "0x77a8E5AC049Ad39ebaD99Abc6fa1261C144B987C";
  
  let web3;
  let contract;
  
  window.onload = async () => {
      // Check if MetaMask is installed
      if (window.ethereum) {
          web3 = new Web3(window.ethereum);
  
          // Request account access from MetaMask
          await window.ethereum.request({ method: 'eth_requestAccounts' });
  
          // Initialize contract instance
          contract = new web3.eth.Contract(abi, contractAddress);
  
          console.log("Connected to contract at address:", contractAddress);
      } else {
          alert("Please install MetaMask to use this DApp!");
      }
  };
  
  // Generate bill function
  async function generateBill() {
      const accounts = await web3.eth.getAccounts();
      const userAccount = accounts[0]; // Get the user's MetaMask account
  
      const prevReading = document.getElementById("prevReading").value;
      const currReading = document.getElementById("currReading").value;
  
      if (!prevReading || !currReading) {
          alert("Please enter valid meter readings!");
          return;
      }
  
      try {
          // Call the smart contract's generateBill function
          await contract.methods.generateBill(prevReading, currReading).send({ from: userAccount });
  
          // Fetch the bill details from the contract
          const bill = await contract.methods.getBill().call({ from: userAccount });
  
          // Display the bill details in the UI
          document.getElementById("billDetails").innerHTML = `
              <p>Units Used: ${bill.unitsUsed}</p>
              <p>Bill Amount: ${bill.billAmount} (in Wei)</p>
          `;
      } catch (error) {
          console.error("Error generating bill:", error);
      }
  }
  