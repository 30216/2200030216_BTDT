async function main() {
    const ElectricityBill = await ethers.getContractFactory("ElectricityBill");
    const contract = await ElectricityBill.deploy(10); // Set rate per unit as 10
    await contract.deployed();

    console.log("ElectricityBill deployed to:", contract.address);
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
